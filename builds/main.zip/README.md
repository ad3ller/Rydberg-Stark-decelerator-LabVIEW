# Rydberg Stark decelerator

v0.0.2

Generate trapping waveforms for a beam of Rydberg atoms above a linear Stark decelerator.

Requires LabVIEW 2013 and NI Gmath.

